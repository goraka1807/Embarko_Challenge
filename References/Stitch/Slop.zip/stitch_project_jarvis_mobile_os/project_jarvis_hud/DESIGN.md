---
name: Project Jarvis HUD
colors:
  surface: '#0e141a'
  surface-dim: '#0e141a'
  surface-bright: '#343a41'
  surface-container-lowest: '#090f15'
  surface-container-low: '#161c23'
  surface-container: '#1a2027'
  surface-container-high: '#252a32'
  surface-container-highest: '#2f353d'
  on-surface: '#dde3ec'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dde3ec'
  inverse-on-surface: '#2b3138'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#43e7e3'
  on-secondary: '#003736'
  secondary-container: '#00cbc7'
  on-secondary-container: '#00504f'
  tertiary: '#fff4e8'
  on-tertiary: '#412d00'
  tertiary-container: '#ffd386'
  on-tertiary-container: '#7d5800'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#5bf9f5'
  secondary-fixed-dim: '#30dcd8'
  on-secondary-fixed: '#00201f'
  on-secondary-fixed-variant: '#00504e'
  tertiary-fixed: '#ffdea8'
  tertiary-fixed-dim: '#ffba20'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4200'
  background: '#0e141a'
  on-background: '#dde3ec'
  surface-variant: '#2f353d'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: 0.08em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.1em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.08em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0.06em
  body-lg:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.02em
  body-md:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.02em
  body-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.12em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.14em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.16em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-fidelity tactical operating interface built for real-time cybernetic orchestration, telemetry monitoring, and diagnostic control. Targeted at pilots, specialized engineers, and high-performance tactical operators, the interface evokes hyper-competence, calm under duress, absolute precision, and futuristic authority. 

Drawing from sci-fi heads-up displays (HUD), military avionics, and sleek dark glassmorphism, the aesthetic pairs midnight obsidian voids with luminous holographic energy conduits. Visual weight is maintained through razor-thin reticle lines, radial dials, segmental energy bars, and high-contrast telemetry indicators that pierce the dark substrate without visual clutter.

## Colors

The palette revolves around deep atmospheric blacks, high-tech cyans, and critical tactical accents:

- **Midnight Obsidian (`#03070D`)**: Primary viewport canvas background.
- **Titanium Dark Layers (`#08121E`, `#0E1F30`)**: Elevated modular containers, surface panels, and radial gauge backgrounds.
- **Holographic Electric Cyan (`#00F0FF`)**: Primary energy vector, interactive rings, active borders, and primary status indicators.
- **Ice Blue Glow (`#4DEEEA`)**: Secondary highlights, subtle particle glows, reticle accents, and hovering state lighting.
- **Telemetry Pure White (`#FFFFFF`, `#E2F8FF`)**: High-contrast readouts, critical metric values, and primary headings.
- **Tactical Amber (`#FFB800`)**: Diagnostic cautions, elevated thruster warnings, and alternate radial ring segments.
- **Warning Crimson (`#FF334B`)**: Mission-critical abort states, failure alerts, and emergency overrides.

## Typography

The type hierarchy balances technical aerospace precision with instant glanceability. 

- **Display & Headlines (`Space Grotesk`)**: Uppercase styling with expanded tracking (`0.06em` to `0.1em`). Used for mode titling, telemetry groupings, suit designations (e.g., `MK-42`), and primary HUD labels.
- **Telemetry Readouts & Labels (`JetBrains Mono`)**: Strict tabular monospace numbers ensure steady alignment across rapid numerical updates (percentages, velocities, coordinate readouts). All labels are set in uppercase to match aerospace avionics standards.
- **Body & Supporting Text (`Geist`)**: Neutral, sharp, modern sans-serif designed for micro-legibility inside HUD cards and component breakdowns.

## Layout & Spacing

Designed specifically around a mobile 390x844px tactical viewport, layout density prioritizes vertical hierarchy, clear reticle crosshairs, and peripheral telemetry cards that leave the primary visual center clear.

- **Grid & Safe Zones**: A fluid 4-column mobile grid with `16px` (`1rem`) gutters and `20px` (`1.25rem`) outer screen margins. Safe areas reserve top 44px for HUD status/clock bar and bottom 34px for quick command triggers and home swipe indicators.
- **HUD Modular Pods**: Peripheral telemetry pods snap to symmetrical top/bottom clusters, framing focal 3D interactive models, radial compass rings, or reactor cores.
- **Rhythm & Gaps**: Compact spacing (`space-xs` and `space-sm`) separates icon glyphs from metrics, while `space-lg` creates separation between functional diagnostic zones.

## Elevation & Depth

Visual depth is achieved through glassmorphic obsidian layers, luminous photon edges, and volumetric neon diffusion:

- **Surface Layers**: Deep midnight containers (`rgba(8, 18, 30, 0.72)`) feature backdrop blurs (`backdrop-filter: blur(16px)`), allowing holographic backgrounds, 3D armor wireframes, and particle grids to shimmer beneath.
- **Luminous Strokes**: Cards and nodes reject heavy flat borders in favor of a crisp `1px` translucent cyan boundary (`rgba(0, 240, 255, 0.28)`), ramping to `rgba(0, 240, 255, 0.75)` along corner brackets and chamfered edges.
- **Holographic Glows**: Glow is treated as light emitting from circuits. Critical rings and primary buttons employ dual neon drop shadows: an immediate razor rim (`0 0 4px rgba(0, 240, 255, 0.8)`) backed by a diffused ambient corona (`0 0 16px rgba(0, 240, 255, 0.25)`).
- **Scanlines & Atmospheric Texture**: A 2px repeating linear gradient mask simulates CRT tactical rasterization across glass surfaces, giving nodes tangible hardware depth.

## Shapes

The geometric identity balances cybernetic chamfers with technical circular hubs:

- **Roundedness Level**: Defined at `1` (Soft, 4px base radius) for rectangular modules, but modified via angled 45-degree polygon chamfers on prominent buttons and telemetry containers.
- **Radial Geometries**: Command switches, navigational compasses, and energy monitors leverage pure concentric circular rings (100% border radius) paired with tick marks and broken dashes.
- **Corner Brackets**: Key informational cards terminate in technical L-shaped brackets and crosshairs to reinforce military HUD targeting aesthetics.

## Components

### Buttons & Command Triggers
- **Primary HUD Action (e.g., "EQUIP SUIT", "ANALYSE COMPONENT")**: Chamfered hexagonal pill structure with a 1px electric cyan border, inner ambient cyan gradient (`rgba(0, 240, 255, 0.15)` to `transparent`), chevron indicators (`>>`), and uppercase tracked typography. On press, fills with cyan pulse.
- **Critical Abort Action**: Identical chamfered geometry styled with warning crimson (`#FF334B`) border and ambient core glow.
- **Radial Node Triggers**: Circular glass pods containing an icon centered within an outer glowing circuit ring. Active state emits rotating segmented tick indicators.

### Telemetry Cards & HUD Panels
- **Telemetry Pods**: Translucent obsidian cards (`#08121E` at 65% opacity) bordered by 1px cyan lines with accented corner cuts. Top-left contains small label text (e.g., `STABILITY`, `AIRSPEED`), middle contains oversized bold monospace values, and bottom displays a micro-segmented status meter.
- **Modular HUD Callouts**: Thin technical leader lines connecting specific 3D model regions to floating rectangular readouts displaying `ONLINE` status tags.

### Gauges & Segmented Progress Bars
- **Arc Progress Meters**: Semi-circular concentric rings displaying percentage completeness with a glowing lead indicator dot.
- **Segmented Horizontal Bars**: Micro-blocks (8 to 12 individual ticks) that illuminate sequentially from dim cyan (`#0E2A3A`) to full electric cyan (`#00F0FF`) with white cap highlights.

### Chips & Tactical Badges
- **Status Chips**: Micro-capsule pills containing a 4px luminous diamond bullet. Text displays system states (`ONLINE`, `STANDBY`, `OFFLINE`).

### Input Fields & Sliders
- **Cybernetic Sliders**: Fine 1px track with numerical tick-marks. Thumb is a luminous diamond reticle with real-time hovering tooltip displaying exact coordinates or output levels.
- **Terminal Inputs**: Dark recessed boxes with blinking monospace cursor and leading prompt glyph (`>`).